# edu_platform
This is an AI-driven EDU platform designed for both teachers and students, allowing up-to-date AI-powered course designing and learning experience.

## Installation and Environment
Conda
Python=3.10.x
node=22.13.0
npm=10.9.2