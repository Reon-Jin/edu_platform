// src/pages/TeacherPage.jsx
import React from 'react';

export default function TeacherPage() {
  return <h2>教师页面</h2>;
}
