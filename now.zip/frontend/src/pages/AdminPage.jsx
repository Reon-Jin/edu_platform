// src/pages/AdminPage.jsx
import React from 'react';

export default function AdminPage() {
  return <h2>管理员页面</h2>;
}
