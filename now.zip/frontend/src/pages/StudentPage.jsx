// src/pages/StudentPage.jsx
import React from 'react';

export default function StudentPage() {
  return <h2>学生页面</h2>;
}
